# boringssl-compat

This wrapper library can be LD_PRELOADed to fill in the missing functions in
BoringSSL compared to OpenSSL.
